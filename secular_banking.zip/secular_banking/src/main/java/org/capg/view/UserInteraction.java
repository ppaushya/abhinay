package org.capg.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.util.Utility;




public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	
	
	
	List<Transaction> summary=new ArrayList<>();
	ICustomerService customerService=new CustomerServiceImpl();
	public void printCustomers(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobileNo() );
		}
	}

	public Customer getCustomerDetails() {
		
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setEmailId(promptEmailId());
		customer.setMobileNo(promptMobile());
		customer.setDateOfBirth(promptDateOfBirth());
		
		customer.setAddress(getAddressDetails());
		customer.setAccount(new HashSet<Account>());
		
		return customer;
	}
	
	
	
	
	public Address getAddressDetails() {
		Address address=new Address();
		System.out.println("Enter AddressLine1:");
		address.setAddressLine1(scanner.next());
		System.out.println("Enter AddressLine2:");
		address.setAddressLine2(scanner.next());
		System.out.println("Enter City:");
		address.setCity(scanner.next());
		System.out.println("Enter State:");
		address.setState(scanner.next());
		address.setPinCode(promptPincode());
		return address;
	}
	
	
	public String promptPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=scanner.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}

	public LocalDate promptDateOfBirth() {
		boolean flag=false;
		String dob;
		do {
			System.out.println("Enter DateOfBirth[dd-mm-yyyy]:");
			dob=scanner.next();
			flag=Utility.isValidDob(dob);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=dob.split("-");
		LocalDate date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return date;
	}
	
	public String promptMobile() {
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter mobile Number:");
			mobile=scanner.next();
			flag=Utility.isValidMobile(mobile);
			if(!flag)
				System.out.println("Please enter Valid 10 digit Mobile!");
		}while(!flag);
		
		return mobile;
	}
	
	public String promptFirstName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter FirstName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid FirstName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptLastName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter LastName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid LastName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptEmailId() {
		boolean flag=false;
		String email;
		do {
			System.out.println("Enter EmailId:");
			email=scanner.next();
			flag=Utility.isValidEmail(email);
			if(!flag)
				System.out.println("Please enter Valid EmailId!");
		}while(!flag);
		
		return email;
	}
public Account promptAccountDetails() {
	AccountType actype=AccountType.SAVINGS;
	Account acc=new Account();
	int accountNo=Utility.generateNumber();
	System.out.println("Choose account type u want to create 1.Savings 2.FD 3.RD 4.Current");
	int choice =scanner.nextInt();
	switch(choice)
	{
	case 1:
		actype=AccountType.SAVINGS;
		break;
	case 2:
		actype=AccountType.FD;
	break;
	case 3:
		actype=AccountType.RD;
		break;
	case 4:
		actype=AccountType.CURRENT;
		break;
		default:
			System.out.println("Account type doesn't exist");
		break;
		
	}
	LocalDate openingdate=LocalDate.now();
	System.out.println("Enter Opening Balance");
	
	
	Double openingBalance=scanner.nextDouble();
	System.out.println("Enter Description:");
	String desc=scanner.next();
	acc.setAccountNumber(accountNo);
	acc.setAccountType(actype);
	acc.setIopeningdate(openingdate);
	acc.setOpeningBalance(openingBalance);
	acc.setDescription(desc);
	return acc;
}

public void customerAccounts(Customer cus)
{
	
Set<Account> acc1=cus.getAccount();
System.out.println("AccountNo\tAccountType\tOpenongDate\tOpeningBalance\tDescription");
System.out.println("-----------------------------------------------------------------------------");
for(Account ac:acc1)
{
	System.out.println(ac.getAccountNumber()+"\t\t"+ac.getAccountType()+"\t\t"+ac.getIopeningdate()+"\t\t"+ac.getOpeningBalance()+"\t\t"+ac.getDescription());
}
		
	
}

public Transaction promptTransactions()
{
	Transaction transaction=new Transaction();
	System.out.println("What type of Transaction?");
	System.out.println("1.Deposit\n2.Withdraw\n3.FundTransfer");
	int ch=scanner.nextInt();
	String transactionType="";
	switch(ch)
	{
	case 1:
		transactionType="Deposit";
		break;
	case 2:
		transactionType="WithDraw";
		break;
	case 3:
		transactionType="Fund Transfer";
		break;
		default:
			System.out.println("Invalid Choice!!");
			break;
			
	}
	int transactionNo=Utility.generateNumber();
	LocalDate transactiondate=LocalDate.now();
	System.out.println("Enter amount to be transacted:");
	double transactionAmount=scanner.nextDouble();
	System.out.println("Enter Description");
	String desc=scanner.next();
	transaction.setTransactionId(transactionNo);
	transaction.setTransactionType(transactionType);
	transaction.setTransactionDate(transactiondate);
	transaction.setAmount(transactionAmount);
	transaction.setDescription(desc);
		
	return transaction;
}
public Account findAccount(Customer customer,int accountNo)
{
	Set<Account> account=customer.getAccount();
	for(Account a:account)
	{
		if(a.getAccountNumber()==accountNo)
		{
			return a;
		}
	}
	return null;
}

public List<Transaction> performTransaction()

{
	Transaction transaction=new Transaction();
	String opt="";
	do {
	List<Customer> customers2= customerService.getAllCustomers();
	printCustomers(customers2);
	System.out.println("Choose CustomerId");
	int customerId2 = scanner.nextInt();
Customer cust2=customerService.isFound(customerId2);
	
	
	if(cust2==null)
	{
		System.out.println("Customer does not exist");
		break;
	}
	 transaction=promptTransactions();
	customerAccounts(cust2);
	if(transaction.getTransactionType()=="WithDraw")
	{
		System.out.println("Choose  Account");
		int fromAccount=scanner.nextInt();
		Account account1=findAccount(cust2, fromAccount);
		if(account1==null)
		{
			System.out.println("Account not found");
			break;
		}
		if(account1.getOpeningBalance()<transaction.getAmount())
		{
			System.out.println("Sorry!U cannot make Transaction");
			break;
		}
		else {
		account1.setOpeningBalance(account1.getOpeningBalance()-transaction.getAmount());
		transaction.setFromAccount(account1);
		}
		
		
	}
	else if(transaction.getTransactionType()=="Deposit")
		{
			System.out.println("Choose  Account");
			int fromAccount=scanner.nextInt();
			Account account2=findAccount(cust2, fromAccount);
			if(account2==null)
			{
				System.out.println("Account not found");
				break;
			}
			
			account2.setOpeningBalance(account2.getOpeningBalance()+transaction.getAmount());
			transaction.setFromAccount(account2);
			
			
		}
	else {
		System.out.println("Choose from Account");
		int fromAccount=scanner.nextInt();
		Account account1=findAccount(cust2, fromAccount);
		System.out.println("Enter the customer Id to transfer amount");
		
		int custId=scanner.nextInt();
		Customer custom=customerService.isFound(custId);
		System.out.println("Choose To  Account Number:");
		int toAccount=scanner.nextInt();
		Account account2=findAccount(custom, toAccount);
		if(account1.getOpeningBalance()<transaction.getAmount())
		{
			System.out.println("Sorry!U cannot make Transaction");
			break;
		}
		else {
		account1.setOpeningBalance(account1.getOpeningBalance()-transaction.getAmount());
		account2.setOpeningBalance(account2.getOpeningBalance()+transaction.getAmount());
		transaction.setFromAccount(account1);
		transaction.setToAccount(account2);
		}
		
	}
	summary.add(transaction);
	System.out.println(transaction);
	System.out.println("Want to continue to do transaction:[Y|N]");
	 opt=scanner.next();
	
	}while(opt.charAt(0)=='y'||opt.charAt(0)=='Y');
	
	return summary;
}

public void printTransaction(List<Transaction> transaction)
{
	java.util.Collections.reverse(transaction);
	System.out.println("TransactionID\tTransactionType\tTransaction\tAmount\tCurrentBalance");
	for(Transaction trans: transaction)
	{
	
		System.out.println(trans.getTransactionId()+"\t\t"+trans.getTransactionType()+"\t\t"+trans.getAmount()+"\t\t"+trans.getFromAccount().getOpeningBalance());
	}
	
}
	public void printError(String message) {
		System.out.println(message);
		
		
	}
	
	
}
