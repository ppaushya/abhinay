package org.capg.model;

import java.time.LocalDate;

public class Account {
private long accountNumber;


private AccountType accountType;
private LocalDate iopeningdate;
private double openingBalance;
private String description;



public Account() {
	
}
@Override
public String toString() {
	return "Account [accountNumber=" + accountNumber + ", iopeningdate=" + iopeningdate + ", openingBalance="
			+ openingBalance + ", description=" + description + "]";
}
public Account(long accountNumber, AccountType accountType, LocalDate iopeningdate, double openingBalance,
		String description) {
	super();
	this.accountNumber = accountNumber;
	this.accountType = accountType;
	this.iopeningdate = iopeningdate;
	this.openingBalance = openingBalance;
	this.description = description;
}
public long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(long accountNumber) {
	this.accountNumber = accountNumber;
}
public AccountType getAccountType() {
	return accountType;
}
public void setAccountType(AccountType accountType) {
	this.accountType = accountType;
}
public LocalDate getIopeningdate() {
	return iopeningdate;
}
public void setIopeningdate(LocalDate iopeningdate) {
	this.iopeningdate = iopeningdate;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}

}
