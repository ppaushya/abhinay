package org.capg.model;

import java.time.LocalDate;

public class Account {
private long accountnumber;
private AccountType accountType;
private LocalDate openingDate;
public Account() {
	super();
}
public Account(long accountnumber, AccountType accountType, LocalDate openingDate, double openingBalance,
		String description) {
	super();
	this.accountnumber = accountnumber;
	this.accountType = accountType;
	this.openingDate = openingDate;
	this.openingBalance = openingBalance;
	this.description = description;
}
@Override
public String toString() {
	return "Account [accountnumber=" + accountnumber + ", openingDate=" + openingDate + ", openingBalance="
			+ openingBalance + ", description=" + description + "]";
}
private double openingBalance;
private String description;
public long getAccountnumber() {
	return accountnumber;
}
public void setAccountnumber(long accountnumber) {
	this.accountnumber = accountnumber;
}
public AccountType getAccountType() {
	return accountType;
}
public void setAccountType(AccountType accountType) {
	this.accountType = accountType;
}
public LocalDate getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(LocalDate openingDate) {
	this.openingDate = openingDate;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}

}
