package org.capg.model;

import java.time.LocalDate;
import java.util.Set;

public class Customer {
private int customerid;
private String firstname;
private String lastname;
private String emailid;
private String mobileno;
private LocalDate dateofbirth;
private Address address;
private Set<Account> accounts;
@Override
public String toString() {
	return "Customer [customerid=" + customerid + ", firstname=" + firstname + ", lastname=" + lastname + ", emailid="
			+ emailid + ", mobileno=" + mobileno + ", dateofbirth=" + dateofbirth + ", address=" + address
			+ ", accounts=" + accounts + "]";
}
public Customer() {
	super();
}
public Customer(int customerid, String firstname, String lastname,LocalDate dateofbirth, String emailid, String mobileno,
		Address address) {
	super();
	this.customerid = customerid;
	this.firstname = firstname;
	this.lastname = lastname;
	this.emailid = emailid;
	this.mobileno = mobileno;
	this.dateofbirth = dateofbirth;
	this.address = address;
	
}
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public LocalDate getDateofbirth() {
	return dateofbirth;
}
public void setDateofbirth(LocalDate dateofbirth) {
	this.dateofbirth = dateofbirth;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Set<Account> getAccounts() {
	return accounts;
}
public void setAccounts(Set<Account> accounts) {
	this.accounts = accounts;
}

}
