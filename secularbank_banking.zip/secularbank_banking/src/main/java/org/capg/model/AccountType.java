package org.capg.model;

public enum AccountType {
	SAVINGS,CURRENT,FD,RD;

}
