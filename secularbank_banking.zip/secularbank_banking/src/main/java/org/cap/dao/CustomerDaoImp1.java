package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDaoImp1 implements CustomerDao {
	
	private static List<Customer> customers=dummydb();
	private static List<Customer> dummydb(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("6 shakti","nagar model gram","ludhiana","punjab","141002");
		customers.add(new Customer(123,"jack","thomas",LocalDate.of(1987,12,13),"abc@gmail.com","9797979797",address));
		
		Address address1=new Address("89 shakti","nagar model gram","ludhiana","punjab","141002");
		customers.add(new Customer(123,"jack","thomas",LocalDate.of(1996,11,05),"cde@gmail.com","9464177164",address1));
		
		Address address2=new Address("101 shakti","nagar model gram","ludhiana","punjab","141002");
		customers.add(new Customer(123,"jack","thomas",LocalDate.of(1998,10,9),"pqr@gmail.com","9464155144",address2));
		
		Address address3=new Address("154 shakti","nagar model gram","ludhiana","punjab","141002");
		customers.add(new Customer(123,"jack","thomas",LocalDate.of(1999,12,12),"hij@gmail.com","8789548747",address3));
		
		return customers;
	}
	@Override
	public  List<Customer> getAllCustomers() {
		
		return customers;
	}
	@Override
	public void createCustomer(Customer customer) {
		customers.add(customer);
		
	}
		
	}

	

