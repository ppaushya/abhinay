package org.cap.dao;

import java.util.List;

import org.capg.model.Customer;

public interface CustomerDao {
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
	
	

}
