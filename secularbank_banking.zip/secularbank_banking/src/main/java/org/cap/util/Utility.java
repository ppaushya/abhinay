package org.cap.util;

public class Utility {
            public static int generateNumber()
            {
            	return (int)((Math.random()*1000/100));
            }
            public static  boolean isValidname(String name)
            {
            	return(name.matches("[a-zA-Z]{3,}"));
            }
	
            public static boolean isValidmobileno(String number)
            {
            	return (number.matches(("\\d{10}")));
            }
            
            public static boolean isValidemailid(String email)
            {
            	return (email.matches("[a-z0-9.]+@gmail.com"));
            }
            
            public static boolean isValidpincode(String number)
            {
            	return (number.matches(("\\d{6}")));
            }
            
            
            
            
            public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
