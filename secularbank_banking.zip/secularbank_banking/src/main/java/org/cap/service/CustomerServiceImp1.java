package org.cap.service;

import java.time.LocalDate;
import java.util.List;

import org.cap.dao.CustomerDao;
import org.cap.dao.CustomerDaoImp1;
import org.capg.model.Customer;

public class CustomerServiceImp1 implements ICustomerservice {

private CustomerDao CustomerDao1=new CustomerDaoImp1();
	
	

	
		private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDateofbirth().isBefore(LocalDate.now())) {
			if(customer.getMobileno().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
			CustomerDao1.createCustomer(customer);
		}
		
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		return CustomerDao1.getAllCustomers();
		}

	
}
