package org.cap.service;

import java.util.List;

import org.capg.model.Customer;

public interface ICustomerservice {
public void createCustomer(Customer customer);
public  List<Customer> getAllCustomers() ;
	// TODO Auto-generated method stub


}
