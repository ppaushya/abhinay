package org.cap.view;
import java.util.List;
import java.util.Scanner;

import org.cap.util.Utility;
import org.capg.model.Address;
import org.capg.model.Customer;
public class UserInteraction {
	Scanner scan=new Scanner(System.in);
	
	public void printcustomers(List<Customer> customers)
	{
		System.out.println("customerid\tfirstname\tlastname\temailid\tmobileno\tdateofbirth\taddress");
		for(Customer customer:customers)
			System.out.println(customer.getCustomerid() +"\t" +customer.getFirstname() + " "
		   +customer.getLastname() +"\t" +customer.getEmailid() + "\t" +customer.getMobileno());
		
	}
	
	
	
	public Customer getCustomerDetails(){
		
	Customer customer=new Customer();
	customer.setCustomerid(Utility.generateNumber());
	customer.setFirstname(promptfname());
	customer.setLastname(promptlname());
	customer.setMobileno(promptmobileno());
	customer.setMobileno(promptemailid());
	
	
       return customer;
	}   
     
	public Address getAddressDetails() {
    	 
    	   Address address=new Address();
    	  String line1,line2,city,state,pincode;
    	  System.out.println("enter addressline 1");
    	  line1=scan.next();
    	  System.out.println("enter addressline 2");
    	  line2=scan.next();
    	  System.out.println("enter city");
    	  city=scan.next();
    	  System.out.println("enter state");
    	  state=scan.next();
    	  System.out.println("enter pincode");
    	  address.setPincode(promptpincode());
       
       return address;
       }
	
	
		
			
	public String promptfname() {
			String fname;
			boolean flag=false;
			do {
				System.out.println("enter first name");
				fname=scan.next();
				//flag=utility.isvalidname(name)
				flag=Utility.isValidname(fname);
				if(!flag)
					System.out.println("please enter a valid name");
			}
			while(!flag);
			return fname;
		}
	
	public String promptlname() {
		String lname;
		boolean flag=false;
		do {
			System.out.println("enter last name");
			lname=scan.next();
			//flag=utility.isvalidname(name)
			flag=Utility.isValidname(lname);
			if(!flag)
				System.out.println("please enter a valid name");
		}
		while(!flag);
		return lname;
	}
	public String promptmobileno() {
		String mobileno;
		boolean flag=false;
		do {
			System.out.println("enter last name");
			mobileno=scan.next();
			//flag=utility.isvalidname(name)
			flag=Utility.isValidmobileno(mobileno);
			if(!flag)
				System.out.println("please enter a valid name");
		}
		while(!flag);
		return mobileno;
	}

	public String promptemailid() {
		String emailid;
		boolean flag=false;
		do {
			System.out.println("enter last name");
			emailid=scan.next();
			//flag=utility.isvalidname(name)
			flag=Utility.isValidmobileno(emailid);
			if(!flag)
				System.out.println("please enter a valid name");
		}
		while(!flag);
		return emailid;
	}
	
	public String promptpincode() {
		String pincode;
		boolean flag=false;
		do {
			System.out.println("enter pincode");
			pincode=scan.next();
			//flag=utility.isvalidname(name)
			flag=Utility.isValidpincode(pincode);
			if(!flag)
				System.out.println("please enter a valid name");
		}
		while(!flag);
		return pincode;
}
	
	public void printError(String message) {
		System.out.println(message);
		
	}
}


