package org.cap.boot;
import java.util.List;
import java.util.Scanner;

import org.cap.service.CustomerServiceImp1;
import org.cap.service.ICustomerservice;
import org.cap.view.UserInteraction;
import org.capg.model.Customer;

public class BootClass {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		ICustomerservice  customerservice=new CustomerServiceImp1();	
		UserInteraction use=new UserInteraction();
		Customer customer=use.getCustomerDetails();
		
		
		
		int choice;
		String option;
		do
		{
			System.out.println("Create customer");
			System.out.println("List customer");
			System.out.println("enter choice");
			choice=scan.nextInt();
			
			switch(choice) {
			case 1:
				
				int count=customerservice.getAllCustomers().size();
			
			Customer customer1=use.getCustomerDetails();
			customerservice.createCustomer(customer1);
			
			
			if(count==customerservice.getAllCustomers().size())
				use.printError("Customer Creation Error! Please Try Again!");
				
			
			break;
			
case 2:
				
				List<Customer> customers= customerservice.getAllCustomers();
				use.printcustomers(customers);
				break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
			
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scan.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
			}
			
		

	}

	


