package day4demo;
import java.util.Scanner;

public class reverseorder {
public String ReverseOrder(String str)
{ String s="";
for(int i=str.length()-1;i>=0;i--)
{
s=s+str.charAt(i);
}
return s;
}
public static void main(String[] args)
{
  reverseorder obj=new reverseorder();
  Scanner scan=new Scanner(System.in);
  System.out.println("Enter the string:");
  String s1=scan.nextLine();
  String res=obj.ReverseOrder(s1);
  System.out.println("Reversed string is:");
  System.out.println(res);
}
}