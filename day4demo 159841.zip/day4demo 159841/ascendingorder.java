package day4demo;
import java.util.Scanner;

public class ascendingorder {
	String str;
	Scanner scan=new Scanner(System.in);
     char temp1;
     char[] str1=new char[10];

     public void alphabetsoup() {
    str=scan.next();
   
     
     for(int i=0;i<str.length();i++)
    	 {
    	 str1[i]=str.charAt(i);
    	 }
     for(int j=0;j<str.length();j++)
    	 {
    	 for(int k=0;k<j+1;k++)
    		 {
    		 if (str1[j]<str1[k])
    		 {
    			 temp1=str1[j];
    		 str1[j]=str1[k];
    		 str1[k]=temp1;}
    	 }
     }
     }
     public void printletters(){
    	 for(int l=0;l<str1.length;l++)
    		 {System.out.print(str1[l]);
     }
    	
     }
    		 
	
	public static void main(String[] args) {
		ascendingorder obj=new ascendingorder();
		obj.alphabetsoup();
        obj.printletters();
	}

}
