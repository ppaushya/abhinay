package day4demo;
import java.util.Scanner;

public class factorial {
int fact=1;
public void firstfactorial(int num) {
	
	for(int i=1;i<=num;i++)
	{	
	fact=fact*i;
	}
	System.out.println(fact);
}
	public static void main(String[] args) {
		int num=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the number");
		num=scan.nextInt();
		
		factorial obj=new factorial();
		obj.firstfactorial(num);

	}

}
