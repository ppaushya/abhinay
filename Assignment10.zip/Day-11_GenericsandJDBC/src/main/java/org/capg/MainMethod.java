package org.capg;

import java.util.ArrayList;
import java.util.List;

public class MainMethod {

	public static void main(String[] args) {
	
		Sender<String> str=new Sender<>();
		str.setMessage("Hello Cap Employee");
		System.out.println(str.getMessage());
		Sender<Integer> in=new Sender<>();
		in.setMessage(1305);
		System.out.println(in.getMessage());
		List<? extends Sender> l=new ArrayList<>();
		Calculate<Integer,Integer> cal=new Calculate<>();
		cal.setNum1(100);
		cal.setNum2(200);
		System.out.println(cal.getNum1()+cal.getNum2());
	}

}
