package org.capg;

public class Employee <T>{

}
