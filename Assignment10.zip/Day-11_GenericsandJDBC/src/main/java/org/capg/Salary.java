package org.capg;

public class Salary extends Employee {


}
