package day4demo;
import java.util.Arrays;
import java.util.Scanner;
public class anagram {
char Arr1[];
char Arr2[];
Scanner scan=new Scanner(System.in);
public void ag(String str) 
{ char temp;
char Arr1[]=new char[str.length()];
    for(int i=0;i<str.length();i++)
{
	Arr1[i]=str.charAt(i);
}
   for(int j=0;j<str.length();j++)
   {
	   for(int k=j+1;k<str.length();k++) {
		   if(Arr1[j]<Arr1[k])
		   {
			   temp=Arr1[j];
			   Arr1[j]=Arr1[k];
			   Arr1[k]=temp;
			   
			   }
	   }
   }
}

public void ag1(String str1) {
	char temp1;
	char Arr2[]=new char[str1.length()];
	for(int i=0;i<str1.length();i++)
	{	
		Arr2[i]=str1.charAt(i);
	}
	for(int j=0;j<str1.length();j++)
		{
		for(int k=0;k<str1.length();k++)
		{
			temp1=Arr2[j];
			Arr2[j]=Arr2[k];
			Arr2[k]=temp1;
			}
		}
}

public void anag() {
	if(Arrays.equals(Arr1,Arr2)==true)
{
	System.out.println("anagrams");
	
}
	else
	{
		System.out.println("not anagrams");
	}
	}

	
public static void main(String[] args) {
anagram obj=new anagram();
obj.ag("hello");
obj.ag1("jakarta");
obj.anag();
}
}