package day4demo;
import java.util.Scanner;

public class longestword {
	public String longestWord(String str)
	{
	String s="",maxWord="";
	int maxlen=0,p=0;
	for(int i=0;i<str.length();i++)
	{

	if(str.charAt(i)!=' ')
	{
	s=s+str.charAt(i);
	}
	else
	{
	p=s.length();
	if((int) p>maxlen)
	{
	maxlen=p;
	maxWord=s;
	}
	s="";
	}
	}
	return maxWord;
	}
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	longestword obj=new longestword();
	  Scanner scan=new Scanner(System.in);
	  System.out.println("Enter the string: ");
	  String s1=scan.nextLine();
	String longWord=obj.longestWord(s1);
	System.out.println("The longest word in the sentence "+longWord);
	}

	

	}


