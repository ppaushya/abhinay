package day4demo;
import java.util.Arrays;
import java.util.Scanner;
public class capital_letters {
	char Arr1[];
	Scanner scan=new Scanner(System.in);
	public void ag(String str) 
	{ //char temp;
		char Arr1[]=new char[str.length()];
	    for(int i=0;i<str.length();i++)
	{
		Arr1[i]=str.charAt(i);
	}
	 Arr1[0]=(char)(Arr1[0]-32);
	    
	for(int i=0;i<str.length()-1;i++)
		{if(Arr1[i]==' ')
			{
			
			Arr1[i+1]=(char)(Arr1[i+1]-32);
			}
		}
	
	
	//public void printelements() {
		for(int i=0;i<str.length();i++)
			System.out.print(Arr1[i]);
	
			
	}			
	public static void main(String[] args) {
		
capital_letters obj=new capital_letters();
obj.ag("hello my name is anthony");
	}

}
