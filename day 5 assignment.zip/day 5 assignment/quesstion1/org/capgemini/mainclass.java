package org.capgemini;
import   balance12.*;
public class mainclass {

	public static void main(String[] args) {
		
		account obj=new account();
		obj.display_balance(1400,700);
		

	}

}
