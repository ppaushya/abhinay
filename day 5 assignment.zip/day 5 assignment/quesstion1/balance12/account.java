package balance12;

public class account {
	int balance,earnings,expenditure;
	public void display_balance(int earnings,int expenditure) {
		balance=earnings-expenditure;
		System.out.println("balance is:" + balance);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
