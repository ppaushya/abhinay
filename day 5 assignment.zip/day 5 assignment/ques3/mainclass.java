
 class mainclass implements division {
    float a,b,c;
	@Override
    public void division12(float a,float b)
	 {
	 {
		 if(b>0)
		 c=a/b;
	 else
		 System.out.println("not possible");
	 }
	 System.out.println("division is:" + c);
	 }
	 
	@Override
	 public void modules() {
		 System.out.println("there are no modules");
	 }
 
	public static void main(String[] args) {
		division obj=new mainclass();
		obj.division12(12.5f, 2.5f);
		obj.modules();
		
		

	}

}
