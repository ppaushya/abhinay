
public interface division {
	static final float a=12,b=10;
	public abstract void division12(float a,float b);
	public abstract void modules();

}
