
 class circle implements area {
	 static final float pi=3.14f;
public float compute(float x,float y) {
return(pi*x*x);

	}

}
