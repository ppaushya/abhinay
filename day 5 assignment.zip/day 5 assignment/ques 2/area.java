
public interface area {
static final float pi=3.14f;
float compute(float x,float y);

}
