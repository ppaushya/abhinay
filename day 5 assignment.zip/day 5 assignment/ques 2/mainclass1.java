
public class mainclass1 {

	public static void main(String[] args) {
		rectangle obj=new rectangle();
		circle obj1=new circle();
		area ar;
		System.out.println("area of rectangle:"+ obj.compute(12.5f,12.6f));
		System.out.println("area of circle:"+ obj1.compute(14.5f,14.8f));
		
		

	}

}
