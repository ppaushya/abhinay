package Register;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	
	private WebDriver webdriver;
	private WebElement element;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
			    "C:\\Users\\ashukla9\\Desktop\\chromedriver\\chromedriver.exe");
		
		webdriver=new ChromeDriver();
		
		 
	}
	
	@Given("^Open Registration page$")
	public void open_Registration_page() throws Throwable {
		 webdriver.get("file:///C:/Users/ashukla9/Desktop/Conferencebooking/Conferencebooking/ConferenceRegistartion.html#"); 
		 String title=webdriver.getTitle();
		    assertEquals("Conference Registartion", title);
		    Thread.sleep(1000);
	}

	@Given("^Valid registration details are entered$")
	public void valid_registration_details_are_entered() throws Throwable {
		 webdriver.findElement(By.name("txtFN")).sendKeys("abhinay");
		 Thread.sleep(1000);
		   webdriver.findElement(By.name("txtLN")).sendKeys("sharma");
		   Thread.sleep(1000);
		   webdriver.findElement(By.name("Email")).sendKeys("abc@gmail.com");
		   Thread.sleep(1000);
		   webdriver.findElement(By.name("Phone")).sendKeys("9464177187");
		   Thread.sleep(1000);
		   Select select=new Select(webdriver.findElement(By.name("size")));
		   select.selectByIndex(2);
		   Thread.sleep(1000);
		   webdriver.findElement(By.name("Address")).sendKeys("shakti nagar");
		   Thread.sleep(1000);
		   webdriver.findElement(By.name("Address2")).sendKeys("model gram");
		   Thread.sleep(1000);
		   Select city=new Select( webdriver.findElement(By.name("city")));
		   city.selectByIndex(1);
		   Thread.sleep(1000);
		   Select state=new Select( webdriver.findElement(By.name("state")));
		   state.selectByIndex(2);
		   Thread.sleep(1000);
		   webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();
		   Thread.sleep(1000);
		   webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input")).click();
		   Thread.sleep(1000);
		
	}

	@When("^Submit Valid Registration details and click next$")
	public void submit_Valid_Registration_details_and_click_next() throws Throwable {
		Thread.sleep(1000);
		element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
	}

	@Then("^Navigate to the Payment page$")
	public void navigate_to_the_Payment_page() throws Throwable {
		Thread.sleep(1000);
		Alert  alertbox=webdriver.switchTo().alert();
		alertbox.accept();
		Thread.sleep(1000);
		
		//webdriver.navigate().to("file:///C:/Users/ashukla9/Desktop/Conferencebooking/Conferencebooking/PaymentDetails.html");
	
	}
	
	@After
	public void teeardown() {
		webdriver.quit();
	}
	
	
	
}
