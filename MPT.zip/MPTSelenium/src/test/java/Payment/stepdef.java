package Payment;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver webdriver;
	private WebElement element;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
			    "C:\\Users\\ashukla9\\Desktop\\chromedriver\\chromedriver.exe");
		
		webdriver=new ChromeDriver();
	}
	
	
	@Given("^Payment page$")
	public void payment_page() throws Throwable {
		 webdriver.get("file:///C:/Users/ashukla9/Desktop/Conferencebooking/Conferencebooking/PaymentDetails.html"); 
		 String title=webdriver.getTitle();
		    assertEquals("Payment Details", title);
		    Thread.sleep(1000);
	}

	@Given("^Enter payment details$")
	public void enter_payment_details() throws Throwable {
		 webdriver.findElement(By.name("txtFN")).sendKeys("abhinayshukla");
		 Thread.sleep(1000);
		 webdriver.findElement(By.name("debit")).sendKeys("71294866");
		 Thread.sleep(1000);
		 webdriver.findElement(By.name("cvv")).sendKeys("083");
		 Thread.sleep(1000);
		 webdriver.findElement(By.name("month")).sendKeys("08");
		 Thread.sleep(1000);
		 webdriver.findElement(By.name("year")).sendKeys("2008");
		 
		 
	}

	@When("^Submit validate payment details and click make payment$")
	public void submit_validate_payment_details_and_click_make_payment() throws Throwable {
		Thread.sleep(1000);
		webdriver.findElement(By.id("btnPayment")).click();
	    
	}

	@Then("^Display confirmation message$")
	public void display_confirmation_message() throws Throwable {
		Thread.sleep(1000);
		Alert  alertbox=webdriver.switchTo().alert();
		Thread.sleep(1000);
		alertbox.accept();
		
	}
	
	@After
	public void teardown() {
		
		webdriver.quit();
	}
}
