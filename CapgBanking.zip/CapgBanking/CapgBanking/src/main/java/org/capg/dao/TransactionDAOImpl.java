package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transactions;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

public class TransactionDAOImpl implements ITransactionDAO{

	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;	
	}
	
	@Override
	public Set<Transactions> getAllTransactions(int customerID) {
		
		ILoginService loginService=new LoginServiceImpl();
		Set<Transactions> transactionSet=new HashSet<>();
		
		String sql="select * from transactions where fromAccount in (select * from account where customerID = ?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setInt(1, customerID);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Transactions transactions=new Transactions();
				
				transactions.setTransactionID(rs.getInt(1));
				transactions.setTransactionDate(rs.getDate(2).toLocalDate());
				transactions.setTransactionType(rs.getString(3));
				transactions.setAmount(rs.getDouble(4));
				transactions.setFromAccount(loginService.getAccountFromAccountNo(rs.getInt(5)));
				transactions.setToAccount(loginService.getAccountFromAccountNo(rs.getInt(6)));
				transactions.setDescription(rs.getString(7));
				
				transactionSet.add(transactions);
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return transactionSet;
	}
}
