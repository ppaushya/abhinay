package org.capg.service;

import java.util.Set;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {
		
		return loginDao.createAccount(account);
	}

	@Override
	public Set<Account> getAccount(int customerID) {
		return loginDao.getAccount(customerID);
	}

	@Override
	public Set<Account> getToAccount(int customerID) {
		return loginDao.getToAccount(customerID);
	}

	@Override
	public Account getAccountFromAccountNo(int accountNo) {
		return loginDao.getAccountFromAccountNo(accountNo);
	}
}
