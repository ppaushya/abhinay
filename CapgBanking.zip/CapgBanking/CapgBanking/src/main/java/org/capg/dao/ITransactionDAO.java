package org.capg.dao;

import java.util.HashSet;
import java.util.Set;

import org.capg.model.Customer;
import org.capg.model.Transactions;

public interface ITransactionDAO {

	public Set<Transactions> getAllTransactions(int customerID);
	
	Set<Transactions> transactions=new HashSet<>();
	
	
	
}
