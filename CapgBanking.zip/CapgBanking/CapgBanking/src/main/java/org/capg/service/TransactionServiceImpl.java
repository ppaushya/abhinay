package org.capg.service;

import java.util.Set;

import org.capg.dao.ILoginDao;
import org.capg.dao.ITransactionDAO;
import org.capg.dao.TransactionDAOImpl;
import org.capg.model.Customer;
import org.capg.model.Transactions;

public class TransactionServiceImpl implements ITransactionService{

	ITransactionDAO transactionDAO=new TransactionDAOImpl();
	
	@Override
	public Set<Transactions> getAllTransactions(int customerID) {
		
		return transactionDAO.getAllTransactions(customerID);
	}

	
}
