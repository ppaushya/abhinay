package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where emailID=? and customerPassword=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(2));
				customer.setLastName(rs.getString(3));
				return customer;
			}	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;	
	}

	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customer(firstName,lastName,dateOfBirth,emailID,mobileNumber,customerPassword)"+
						" values(?,?,?,?,?,?)";
		
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
		
		pst.setString(1, customer.getFirstName());
		pst.setString(2, customer.getLastName());
		pst.setDate(3, Date.valueOf(customer.getDateOfBirth()));
		pst.setString(4, customer.getEmailId());
		pst.setString(5,customer.getMobile());
		pst.setString(6,customer.getCustomerPwd());	
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
			String sqlMax="select max(customerID) from customer";
			try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sqlMax)) {
				ResultSet rs= pst1.executeQuery();
				if(rs.next())
					customerId=rs.getInt(1);
				
				System.out.println(customerId);
				
				String sqlAdd="insert into address(addressLine1,addressLine2,city,state,pincode,customerID) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setString(5, customer.getAddress().getPincode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			flag=false;
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public Account createAccount(Account account) {
		
		String sql="insert into account(accountType, openingDate, openingBalance, description, customerID) values(?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setString(1, account.getAccountType().toString());
			pst.setDate(2, Date.valueOf(account.getOpeningDate()));
			pst.setDouble(3, account.getOpeningBalance());
			pst.setString(4, account.getDescription());
			pst.setInt(5, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Set<Account> getAccount(int customerID) {
		Set<Account> accounts=new HashSet<>();
		
		String sql="select * from account where customerID=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setInt(1, customerID);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				
				account.setAccountNumber(rs.getLong(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningDate(rs.getDate(3).toLocalDate());
				account.setOpeningBalance(rs.getDouble(4));
				account.setDescription(rs.getString(5));
		
				accounts.add(account);
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;
	}
	
	@Override
	public Account getAccountFromAccountNo(int accountNo) {
		
		Account account=new Account();
		
		String sql="select * from account where accountNumber=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setInt(1, accountNo);
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				
				account.setAccountNumber(rs.getLong(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningDate(rs.getDate(3).toLocalDate());
				account.setOpeningBalance(rs.getDouble(4));
				account.setDescription(rs.getString(5));
		
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return account;
	}

	@Override
	public Set<Account> getToAccount(int customerID) {
		
Set<Account> accounts=new HashSet<>();
		
		String sql="select * from account where customerID !=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setInt(1, customerID);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				Account account=new Account();
				
				account.setAccountNumber(rs.getLong(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				account.setOpeningDate(rs.getDate(3).toLocalDate());
				account.setOpeningBalance(rs.getDouble(4));
				account.setDescription(rs.getString(5));
		
				accounts.add(account);
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;
	}
}