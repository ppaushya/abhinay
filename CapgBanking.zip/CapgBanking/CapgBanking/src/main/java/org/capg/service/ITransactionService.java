package org.capg.service;

import java.util.Set;

import org.capg.model.Customer;
import org.capg.model.Transactions;

public interface ITransactionService {

	public Set<Transactions> getAllTransactions(int customerID);
	
}