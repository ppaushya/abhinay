function validateNewCustomer(){
	var flag=false;
	var firstName=signUp.firstName.value;
	var lastName=signUp.lastName.value;
	var dateOfBirth=signUp.dateOfbirth.value;
	var today=new Date();
	var addressLine1=signUp.addressline1.value;
	var addressLine2=signUp.addressline2.value;
	var city=signUp.city.value;
	var state=signUp.state.value;
	var pincode=signUp.pincode.value;
	var emailID=signUp.email.value;
	var mobileNumber=signUp.mobile.value;
	var password=signUp.custPwd.value;
	var confirmPassword=signUp.confimrCustPwd.value;
	
	dateOfBirth = new Date(dateOfBirth);
	
	if(firstName==""||firstName==null){
		clearAllError();
		document.getElementById('firstNameErrMsg').innerHTML="First Name cannot be Empty";
		flag=false;
	}else if(!firstName.match(/^[A-Z]{1}[a-z]{2,}$/)){
		clearAllError();
		document.getElementById('firstNameErrMsg').innerHTML="Enter Valid First Name";
		flag=false;
	}else if(lastName==""||lastName==null){
		clearAllError();
		document.getElementById('latsNameErrMsg').innerHTML="Last Name cannot be Empty";
		flag=false;
	}else if(!lastName.match(/^[A-Z]{1}[a-z]{2,}$/)){
		clearAllError();
		document.getElementById('latsNameErrMsg').innerHTML="Enter Valid Last Name";
		flag=false;
	}else if(dateOfBirth==""||dateOfBirth==null){
		clearAllError();
		document.getElementById('dateErrMsg').innerHTML="Date Of Birth cannot be Empty";
		flag=false;
	}else if(dateOfBirth > today){
		clearAllError();
		document.getElementById('dateErrMsg').innerHTML="We hope you have Taken Birth :P";
		flag=false;
	}else if(addressLine1==""||addressLine1==null){
		clearAllError();
		document.getElementById('addressLine1ErrMsg').innerHTML="Address Line 1 cannot be Empty";
		flag=false;
	}else if(addressLine2==""||addressLine2==null){
		clearAllError();
		document.getElementById('addressLine2ErrMsg').innerHTML="Address Line 2 cannot be Empty";
		flag=false;
	}else if(city==""||city==null){
		clearAllError();
		document.getElementById('cityErrMsg').innerHTML="Please select city";
		flag=false;
	}else if(state==""||state==null){
		clearAllError();
		document.getElementById('stateErrMsg').innerHTML="Please select State";
		flag=false;
	}else if(pincode==""||pincode==null){
		clearAllError();
		document.getElementById('pinCodeErrMsg').innerHTML="Pin Code cannot be Empty";
		flag=false;
	}else if(!pincode.match(/^[0-9]{6}$/)){
		clearAllError();
		document.getElementById('pinCodeErrMsg').innerHTML="Pincode should have 6 digits";
		flag=false;
	}else if(emailID==""||emailID==null){
		clearAllError();
		document.getElementById('emailIDErrMsg').innerHTML="Email ID cannot be Empty";
		flag=false;
	}else if(mobileNumber=="" || mobileNumber==null){
		clearAllError();
		document.getElementById('mobileNumberErrMsg').innerHTML="Mobile Number cannot be Empty";
		flag=false;
	}else if(!mobileNumber.match(/^[7-9]{1}[0-9]{9}$/)){
		clearAllError();
		document.getElementById('mobileNumberErrMsg').innerHTML="Mobile Number should have 10 digits";
		flag=false;
	}else if(password==""||password==null){
		clearAllError();
		document.getElementById('passwordErrMsg').innerHTML="Password cannot be Empty";
		flag=false;
	}else if(confirmPassword==""||confirmPassword==null){
		clearAllError();
		document.getElementById('confirmPasswordErrMsg').innerHTML="Confirm Password cannot be Empty";
		flag=false;
	}else if(password!=confirmPassword){
		clearAllError();
		document.getElementById('confirmPasswordErrMsg').innerHTML="Paswords must match";
		flag=false;
	}else{
		flag=true;
	}
	return flag;
}

function clearAllError() {
	
	document.getElementById('firstNameErrMsg').innerHTML="";
	document.getElementById('latsNameErrMsg').innerHTML="";
	document.getElementById('dateErrMsg').innerHTML="";
	document.getElementById('addressLine1ErrMsg').innerHTML="";
	document.getElementById('addressLine2ErrMsg').innerHTML="";
	document.getElementById('cityErrMsg').innerHTML="";
	document.getElementById('stateErrMsg').innerHTML="";
	document.getElementById('pinCodeErrMsg').innerHTML="";
	document.getElementById('emailIDErrMsg').innerHTML="";
	document.getElementById('mobileNumberErrMsg').innerHTML="";
	document.getElementById('passwordErrMsg').innerHTML="";
	document.getElementById('confirmPasswordErrMsg').innerHTML="";	
}