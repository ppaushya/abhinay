function validateNewAccount(){
	var flag=false;
	var accountType=newAccount.accountType.value;
	var openingBalance=newAccount.balance.value;
	var description=newAccount.description.value;
	
	if(accountType == "SAVINGS"){
	
		if(openingBalance==""||openingBalance==null){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Opening Balance cannot be Empty";
			flag=false;
		}else if(openingBalance < 500){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Minimum Opening Balance is Rs. 500";
			flag=false;
		}
	}else if(accountType == "CURRENT"){
	
		if(openingBalance==""||openingBalance==null){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Opening Balance cannot be Empty";
			flag=false;
		}else if(openingBalance < 5000){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Minimum Opening Balance is Rs. 5000";
			flag=false;
		}
	}else if(accountType == "RD"){
	
		if(openingBalance==""||openingBalance==null){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Opening Balance cannot be Empty";
			flag=false;
		}else if(openingBalance < 500){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Minimum Opening Balance is Rs. 5000";
			flag=false;
		}
	}else if(accountType == "FD"){
	
		if(openingBalance==""||openingBalance==null){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Opening Balance cannot be Empty";
			flag=false;
		}else if(openingBalance < 500){
			clearAllError();
			document.getElementById('openingBalanceErrMsg').innerHTML="Minimum Opening Balance is Rs. 5000";
			flag=false;
		}
	}
	if(description=="" || description==null){
		clearAllError();
		document.getElementById('descriptionErrMsg').innerHTML="Description cannot be Empty";
		flag=false;
	}else{
		flag=true;
	}
	return flag;
}

function clearAllError() {
	
	document.getElementById('openingBalanceErrMsg').innerHTML="";
	document.getElementById('descriptionErrMsg').innerHTML="";
}