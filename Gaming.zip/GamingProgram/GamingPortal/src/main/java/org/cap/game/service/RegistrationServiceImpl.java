package org.cap.game.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.cap.game.dao.IRegistrationDao;
import org.cap.game.dao.RegistrationDaoImpl;
import org.cap.game.exception.InvalidAgeException;
import org.cap.game.model.Registration;


public class RegistrationServiceImpl implements IRegistrationService {
	
	
	final static Logger logger=Logger.getLogger(RegistrationServiceImpl.class);
	
	IRegistrationDao registrationDao=new RegistrationDaoImpl();

	public RegistrationServiceImpl(IRegistrationDao registrationDao) {
		super();
		this.registrationDao = registrationDao;
	}

	public RegistrationServiceImpl()	{}
	
	public void createRegistration(Registration registration) throws InvalidAgeException {
		// TODO Auto-generated method stub
		
			if(registration==null)
			{
				logger.error("Invalid Argument Exception!");
				throw new IllegalArgumentException();
			}
			else if(registration.getAge()<=0)
			{
				logger.error("Invalid Age entered!");
				throw new InvalidAgeException("Invalid Age!");
			}
			
			registrationDao.createRegistration(registration);
		
	
	}

	@Override
	public Registration getRegistrationDetails() {
		// TODO Auto-generated method stub
		
		return registrationDao.getRegistrationDetails();

	}
	
	
	
	

}
