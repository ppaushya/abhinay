package org.cap.game.view;


import java.util.Scanner;

import org.cap.game.model.Registration;
import org.cap.game.service.IRegistrationService;
import org.cap.game.service.RegistrationServiceImpl;

public class UserInteraction {
	Registration registration=new Registration();
	IRegistrationService registrationServices=new RegistrationServiceImpl();
	Scanner sc=new Scanner(System.in);
	
	public Registration getRegistrationDetails()
	{
		registration.setCustomerName(promptCustomerName());
		registration.setMobileNo(promptCustomerMobileNo());
		registration.setRegistrationFees(promptRegistrationFees());
		registration.setAge(promptAge());
		registration.setActualRegistrationFeesPaid(registration.getRegistrationFees()+calculateCommission(registration.getAge(), registration.getRegistrationFees()));
		
		return registration;
	}
	
	public String promptCustomerName()
	{
		while(true)	{
			String name;
			System.out.println("Enter customer Name: ");
			name=sc.next();
			if(isValidCustomerName(name))
				return name;
		}
	}
	
	public boolean isValidCustomerName(String name)
	{
		if(name.matches("[A-Za-z]{3,}"))
			return true;
		else
			return false;	
	}
	
	public String promptCustomerMobileNo()
	{
		while(true) {
			String mobile;
			System.out.println("Enter customer mobile number: ");
			mobile=sc.next();
			if(isValidMobileNo(mobile))
			return mobile;
		}
	}
	
	public boolean isValidMobileNo(String mobile)
	{
		if(mobile.matches("\\d{10}")) 
			return true;
		else
			return false;	
	}
	
	public double promptRegistrationFees()
	{
		double fees;
		System.out.println("Enter registration fees: ");
		fees=sc.nextDouble();
		return fees;
	}
	
	public int promptAge()
	{
		int age;
		System.out.println("Enter customer age: ");
		age=sc.nextInt();
		
		return age;
	}
	
	public double calculateCommission(int age, double fees)
	{
		double commission = 0;
		if(age<18)
			commission=0;
		else if(age>=18 && age<25)
			commission=0.1*fees;
		else if(age>=25 && age<50)
			commission=0.2*fees;
		else if(age>=50)
			commission=0.3*fees;
		
		return commission;
	}
	
	
	public void generateAcknowledgement()
	{
		registration=registrationServices.getRegistrationDetails();
		System.out.println("\n\n\tACKNOWLEDGEMENT SLIP");
		System.out.println("Registration ID: "+registration.getRegistrationId());
		System.out.println("CONGRATULATIONS "+registration.getCustomerName()+"!!");
		System.out.println("Amount paid:\t"+registration.getActualRegistrationFeesPaid()+"\n\n");
	}
	

}
