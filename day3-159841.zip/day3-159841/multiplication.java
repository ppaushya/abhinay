package day4demo;
import java.util.Scanner;
public class multiplication {
Scanner scan=new Scanner(System.in);
	
		int[][] arr=new int[3][3];
		int[][] arr1=new int[3][3];
		int[][] arr2=new int[3][3];
		{
			System.out.println("enter the values");
			}
			{for(int i=0;i<3;i++)
				{
				for(int j=0;j<3;j++)
					arr[i][j]=scan.nextInt();
				}
			}
			{for(int i=0;i<3;i++)
			{
			for(int j=0;j<3;j++)
				arr1[i][j]=scan.nextInt();
			}
			}
			public void multiply() {
				int sum=0;
				for(int i=0;i<3;i++)
					{
					for(int j=0;j<3;j++)
					{
						for(int k=0;k<3;k++)
							sum=sum + arr[i][k]*arr1[k][j];
						arr2[i][j]=sum;
						sum=0;
					}
			}

			}
			
			public void printelements() {
				for(int i=0;i<3;i++)
				{
					for(int j=0;j<3;j++)
						System.out.print(arr2[i][j] + "  ");
					System.out.println();
					
				}
			}

public static void main(String[] args) {
multiplication obj=new multiplication();
obj.multiply();
obj.printelements();
}
}