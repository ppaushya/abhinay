package org.cap.demo;
import java.util.Scanner;
public class matrixaddition {
Scanner scan=new Scanner(System.in);
	int[][] arr=new int[3][3];
	int[][] arr1=new int[3][3];
	int[][] arr2=new int[3][3];
	{
	System.out.println("enter the values");
	}
	{for(int i=0;i<3;i++)
		{
		for(int j=0;j<3;j++)
			arr[i][j]=scan.nextInt();
		}
	}
	{for(int i=0;i<3;i++)
	{
	for(int j=0;j<3;j++)
		arr1[i][j]=scan.nextInt();
	}
	}
 
	public void addition123() {
		for(int k=0;k<3;k++)
			{for(int l=0;l<3;l++)
				arr2[k][l]=arr[k][l]+arr1[k][l];
			}
		
	}
	public void printelements() {
		for(int i=0;i<3;i++)
			{for(int j=0;j<3;j++)
				System.out.println(arr2[i][j]);
			}
	}
	public static void main(String[] args) {
		matrixaddition obj=new matrixaddition();
		obj.addition123();
		obj.printelements();

	}

}
