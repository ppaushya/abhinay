package org.capg.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;



public class Utility {
	
	
   
	
	public static int generateNumber()
	{
		int num=0;
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i=1000; i<1100; i++) {
	        list.add(new Integer(i));
	    }
	    Collections.shuffle(list);
	    for (int i=0; i<3; i++) {
	        num+=list.get(i);
	    }
	    return num;
		 /*Random r = new Random();
		 return r.nextInt((10000) + 1) + 1000;*/
	}
	

	public static String isValidName()	{
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		String name;
		do	{
			System.out.println(" name:");
			name=sc.next();
			flag=name.matches("[a-zA-Z]{3,}");
			if(flag==false)
			{
				System.out.println("Enter valid name!");
			}
		}	while(flag==false);
		return name;
	}
}
