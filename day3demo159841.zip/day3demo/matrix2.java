package org.cap.demo;

import java.util.Scanner;

public class matrix2 {
int[][] arr;
int[] sumA;
Scanner sc=new Scanner(System.in);

public void acceptArray(int r,int c) {
System.out.println("Enter the array elements - ");
arr=new int[r][c];
sumA=new int[r];
for(int i=0;i<r;i++) {
for(int j=0;j<c;j++) {
arr[i][j]=sc.nextInt();
}
}
}
public void subSum(int ro,int co) {
int sum=0;
for(int k=0;k<ro;k++) {
sum=0;
for(int l=0;l<co;l++) {
sum=sum+arr[k][l];
}
System.out.println("sum of row " + k + "- "+sum );
sumA[k]=sum;
}
}
public void minRow(int z) {
int min=sumA[0];
for(int m=1;m<z;m++) {
if(min>sumA[m]) {
min=sumA[m];
}
}
System.out.println("lowest sum is "+min);
}
public static void main(String[] args) {
Scanner scanner=new Scanner(System.in);
System.out.println("Enter no. of rows");
int rows=scanner.nextInt();
System.out.println("Enter no. of columns");
int cols=scanner.nextInt();
matrix2 obj=new matrix2();
obj.acceptArray(rows,cols);
obj.subSum(rows,cols);
obj.minRow(rows);

}
}