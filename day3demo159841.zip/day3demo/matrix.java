package org.cap.demo;
import java.util.Scanner;
public class matrix {
   
	int[][] arr;
	Scanner sc=new Scanner(System.in);
	public void acceptmatrix(int size) {
		System.out.println("enter the elements:");
		arr=new int[size][size];
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				
				arr[i][j]=sc.nextInt();
			}
		}
	}
	
	public void uppertriangle() {
		for(int k=0;k<arr[0].length;k++)
		{for(int l=0;l<arr[0].length;l++) {
			if(k<=l)
				System.out.print(""+arr[k][l]);
			else
				System.out.println(" ");
		}
		}
		System.out.println();
	}
	public void transpose() {
		System.out.println();
		for(int k=0;k<arr[0].length;k++)
		{for(int l=0;l<arr[0].length;l++)
			System.out.print(" "+arr[l][k]);
		}
		System.out.println();
		
		}
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the size of matrix elements");
       int s=scanner.nextInt();
       matrix obj=new matrix();
       obj.acceptmatrix(3);
       obj.uppertriangle();
       obj.transpose();
	}

}
