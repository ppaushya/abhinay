package org.capg.hbms.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.model.RoomType;
import org.capg.hbms.model.Users;
import org.capg.hbms.service.BookingServiceImpl;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IBookingService;
import org.capg.hbms.service.IHotelService;
import org.capg.hbms.service.IRegistrationService;
import org.capg.hbms.service.IRoomService;
import org.capg.hbms.service.RegistrationServiceImpl;
import org.capg.hbms.service.RoomServiceImpl;

public class AdminInteraction {
	static IHotelService hotelservice=new HotelServiceImpl();
		static IBookingService bookingservice=new BookingServiceImpl();
		static IRoomService roomservice=new RoomServiceImpl();
		static IRegistrationService regservice=new RegistrationServiceImpl();
	 static Scanner sc=new Scanner(System.in);
public Hotel PromptHotel()
{
	String option2;
	do{Hotel hotel=new Hotel();
	System.out.println("Enter city");
	hotel.setCity(sc.next());
	System.out.println("Enter Hotel name");
	hotel.setHotel_name(sc.next());
	System.out.println("Enter Address");
	hotel.setAddress(sc.next());
	System.out.println("Enter description");
	hotel.setDescription(sc.next());
	System.out.println("Enter phone no ");
	hotel.setPhone_no1(sc.next());
	System.out.println("Enter alternate phone number");
	hotel.setPhone_no2(sc.next());
	System.out.println("Enter Average cost per night");
	hotel.setAvg_rate_per_night(sc.nextDouble());
	System.out.println("Enter rating");
	hotel.setRating(sc.next());
	System.out.println("Enter email");
	hotel.setEmail(sc.next());
	System.out.println("Enter fax");
	hotel.setFax(sc.next());

	System.out.println("Do you wish to add more hotels [Y|N]");
	option2=sc.next();
	return hotel;
}while(option2.charAt(0)=='Y'||option2.charAt(0)=='y');

}

public static  void GenerateReports()
{
	System.out.println("Choose Functionality");
	System.out.println("1.View List of hotels");
	System.out.println("2.View Users");
	//System.out.println("3.View Bookings for specific Hotel");
	System.out.println("3.View Bookings for specific Date");
	switch(sc.nextInt())
	{
	case 1:
		printHotels(hotelservice.getAllHotels());
		break;
	case 2:
		//System.out.println("Enter the HotelId of the hotel whose guestlist you wish to see");
		printAllUsers(regservice.getAllUsers());
		break;
	case 3:
		printHotels(hotelservice.getAllHotels());
		System.out.println("Enter the hotelId to view Bookings :");
		int hotelId=sc.nextInt();
		//List<RoomDetails>rooms=roomservice.getRooms_with_hotelId(hotelId);
		
			break;
	case 4:
		//LocalDate spdate=sc.next();
		System.out.println("Enter the date[dd-mm-yyyy] to view bookings: ");
		String spdate=sc.next();
		String arr[]=spdate.split("-");
		int dd=Integer.parseInt(arr[0]);
		int mm=Integer.parseInt(arr[1]);
		int yyyy=Integer.parseInt(arr[2]);
		printBookingDetails(bookingservice.getBookings(LocalDate.of(yyyy, mm, dd)));
		break;
		default:
			System.out.println("Invalid Option");
			break;
	}
	
}
public int DeleteHotel()
{
	String option2;
	do{
		printHotels(hotelservice.getAllHotels());
	System.out.println("Enter the id of the hotel u want to delete ");
	int id=sc.nextInt();

	System.out.println("Do you wish to delete more hotels [Y|N]");
	option2=sc.next();
	return id;
}while(option2.charAt(0)=='Y'||option2.charAt(0)=='y');
	
}
public static void printHotels(List<Hotel> hotels)
{
	System.out.println("HotelId\tCity\tHotel_name\tAddress\tDescription\t\tAverageRate\tPhoneNo\tRating\tEmail");
	for(Hotel hotel:hotels)
	{
		
		System.out.println(hotel.getHotel_id()+"\t"+hotel.getCity()+"\t"+hotel.getHotel_name()+"\t"+hotel.getAddress()+"\t"+hotel.getDescription()+"\t\t"+hotel.getAvg_rate_per_night()+"\t"+hotel.getPhone_no1()+"\t"+hotel.getRating()+"\t"+hotel.getEmail());
	}
}
public void modifyHotel()
{
	printHotels(hotelservice.getAllHotels());
	System.out.println("Choose the hotel u want to modify.Enter the hotelid");
	int hid=sc.nextInt();
	List<Hotel> hotels=new ArrayList();
	hotels.add(hotelservice.getHotel_id(hid));
	printHotels(hotels);
	System.out.println("choose what you want to modify.");
	System.out.println("1.Description");
	System.out.println("2.Hotel Name");
	System.out.println("3.Average Rate per night");
	int choice =sc.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("Enter the description you want to set");
		String str=sc.next();
		hotelservice.modifyHotelDescription(str,hid);
		break;
	case 2:
		System.out.println("Enter the hotel name you want to set");
		String str1=sc.next();
		hotelservice.modifyHotelName(str1, hid);
		break;
		
	case 3:
		System.out.println("Enter the new rate you want to set");
		double rate=sc.nextDouble();
		hotelservice.modifyHotelRate(rate, hid);
		break;
		default:
			System.out.println("Invalid Choice");
			break;
		
	}
	
	
}

public static void printBookingDetails(List<BookingDetails> bookingDetails) {

	System.out.println("Booking Id\tRoom Id\tUser Id\tBooked From\tBooked To\tNo. Of Adults\tNo. of Children\t Amount");
		for(BookingDetails bookDetail:bookingDetails) {
		System.out.println(bookDetail.getBooking_id()+"\t\t"+bookDetail.getRoom_id()+"\t\t"+bookDetail.getUser_id()
							+"\t\t"+bookDetail.getBooked_from()+"\t\t"+bookDetail.getBooked_to()+"\t\t"+bookDetail.getNo_of_adults()
							+"\t\t"+bookDetail.getNo_of_children()+"\t\t"+bookDetail.getAmount());
		
	}
	
}
public static void printAllUsers(List<Users> users)
{
	System.out.println("User_id\t Password\t Role\t UserName \tMobileNo\tPhone \tAddress \t Email");
	for(Users user:users)
	{
		System.out.println(user.getUser_id()+"\t"+user.getPassword()+"\t"+user.getRole()+"\t"+user.getUser_name()+"\t"+user.getMobile_no()+"\t"+user.getPhone()+"\t"+user.getAddress()+"\t"+user.getEmail());
	}
}
public RoomDetails promptRoom() {
	RoomDetails room=new RoomDetails();
	
	System.out.println("Enter Room no");
	room.setRoom_no(sc.next());
	System.out.println("Enter HotelId");
	room.setHotel_id(sc.nextInt());
	System.out.println("Enter Room Type");
	room.setRoom_type(RoomType.valueOf(sc.next()));
	System.out.println("Enter per Night Rate");
	room.setPer_night_rate(sc.nextDouble());
	System.out.println("Choose Photo");
	room.setPhoto(sc.next());
	room.setAvailability(true);	
	return room;
}
public int promptRoomid() {
	System.out.println("Enter RoomId");
	int roomId=sc.nextInt();
	return roomId;
}

public RoomDetails changeAvailability() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to alter availability");
	int roomId=sc.nextInt();
	System.out.println("enter availability you want to set");
	Boolean avai=sc.hasNextBoolean();
	roomd.setAvailability(avai);
	roomd.setRoom_id(roomId);
	return roomd;

}
public RoomDetails changeRoomType() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to change room type");
	roomd.setRoom_id(sc.nextInt());
	System.out.println("enter room type you want to set");
	roomd.setRoom_type(RoomType.valueOf(sc.next()));
	return roomd;
}
public RoomDetails changeRoomCost() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to change room cost");
	roomd.setRoom_id(sc.nextInt());
	System.out.println("enter cost you want to set");
	roomd.setPer_night_rate(sc.nextDouble());
	return roomd;
}

}
