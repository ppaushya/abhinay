package org.capg.hbms.view;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.model.Users;
import org.capg.hbms.service.BookingServiceImpl;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IBookingService;
import org.capg.hbms.service.IHotelService;
import org.capg.hbms.service.ILoginService;
import org.capg.hbms.service.IRoomService;
import org.capg.hbms.service.LoginServiceImpl;
import org.capg.hbms.service.RoomServiceImpl;
import org.capg.hbms.util.Utility;


public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	IHotelService hotelservice=new HotelServiceImpl();
	IRoomService roomservice=new RoomServiceImpl();
	ILoginService loginservice=new LoginServiceImpl();
	IBookingService bookingService=new BookingServiceImpl();
	Utility utility = new Utility();
	
	
	public void printBookingDetails(int customerId) {
		Set<BookingDetails> bookingDetails=new HashSet<>();
		bookingDetails=bookingService.getBookingDetails(customerId);
		System.out.println("Booking Id\tRoom Id\tUser Id\tBooked From\tBooked To\tNo. Of Adults\tNo. of Children\t Amount");
		
		for(BookingDetails bookDetail:bookingDetails) {
			System.out.println(bookDetail.getBooking_id()+"\t\t"+bookDetail.getRoom_id()+"\t\t"+bookDetail.getUser_id()
								+"\t\t"+bookDetail.getBooked_from()+"\t\t"+bookDetail.getBooked_to()+"\t\t"+bookDetail.getNo_of_adults()
								+"\t\t"+bookDetail.getNo_of_children()+"\t\t"+bookDetail.getAmount());
			
		}
		
	}
	
	public void printHotels(List<Hotel> hotels)
	{
		System.out.println("HotelId\tCity\tHotel_name\tAddress\tDescription\t\tAverageRate\tPhoneNo\tRating\tEmail");
		for(Hotel hotel:hotels)
		{
			
			System.out.println(hotel.getHotel_id()+"\t"+hotel.getCity()+"\t"+hotel.getHotel_name()+"\t"+hotel.getAddress()+"\t"+hotel.getDescription()+"\t\t"+hotel.getAvg_rate_per_night()+"\t"+hotel.getPhone_no1()+"\t"+hotel.getRating()+"\t"+hotel.getEmail());
		}
	}
	public void printRooms(List<RoomDetails> rooms)
	{
		System.out.println("roomId\troomnumber\troomtype\trate_per_night\tAvailability");
		for(RoomDetails room:rooms)
		{
			
			System.out.println(room.getRoom_id()+"\t"+room.getRoom_no()+"\t"+room.getRoom_type()+"\t"+room.getPer_night_rate()+"\t"+room.isAvailability());
		}
	}
	public BookingDetails bookRooms()
	{
		System.out.println("Enter the city name:");
		List<Hotel> hotels1=hotelservice.getHotels(scanner.next());
		printHotels(hotels1);
		System.out.println("Select a hotel you like.Enter the hotel id displayed along with hotels");
		int h=scanner.nextInt();
		List<RoomDetails> rooms=roomservice.getRooms(h);
		printRooms(rooms);
		System.out.println("If you wish to book please fill the following details");
		BookingDetails bookd=promptBookingDetails();
		System.out.println(bookd);
		
		BookingDetails finalbooking=bookingService.findAmount(bookd);
		RoomDetails roomdetails=roomservice.getRoom_withID(finalbooking.getRoom_id());
		roomservice.changeAvailability(roomdetails);
		bookingService.addbooking(finalbooking);		
		return bookd;
		
		
	}
	public BookingDetails promptBookingDetails()
	{
		BookingDetails bookingdetails=new BookingDetails();
		System.out.println("Enter the room id");
		
		bookingdetails.setRoom_id(scanner.nextInt());
		
	    Users user2=new Users();
		System.out.println("Enter EmailId to login:");
		user2.setEmail(scanner.next());
		System.out.println("Enter password to login:");
		user2.setPassword(scanner.next());
		
		Users user3=loginservice.getUser(user2);
		bookingdetails.setUser_id(user3.getUser_id());
		
		System.out.println("Enter the booked_from date[dd-mm-yyyy]");
		String frmdate=scanner.next();
		String arr[]=frmdate.split("-");
		int dd=Integer.parseInt(arr[0]);
		int mm=Integer.parseInt(arr[1]);
		int yyyy=Integer.parseInt(arr[2]);
		Boolean flag=utility.isvalidFromdate(LocalDate.of(yyyy, mm, dd));
		if(flag) {
		bookingdetails.setBooked_from(LocalDate.of(yyyy, mm, dd));
		System.out.println("enter to date[dd-mm-yyyy]");
		String todate=scanner.next();
		String arr2[]=todate.split("-");
		int day=Integer.parseInt(arr2[0]);
		int month=Integer.parseInt(arr2[1]);
		int year=Integer.parseInt(arr2[2]);
		Boolean flag1=utility.isvalidTodate(LocalDate.of(year, month, day),LocalDate.of(yyyy, mm, dd));
		//System.out.println(flag1);
		if(flag1){
		bookingdetails.setBooked_to(LocalDate.of(year, month, day));
		System.out.println("enter no_of_adults");
		
		bookingdetails.setNo_of_adults(scanner.nextInt());
		
		System.out.println("enter no_of_children");
		
		bookingdetails.setNo_of_children(scanner.nextInt());
	
		
		}
		}
		else {
			System.exit(0);
		}
		return bookingdetails;
	}
	public Users userRegistration() {
		
		
		Users user=new Users();
	
		
		
		boolean flag=false;
		do {
		System.out.println("Enter Role[User|Employee]:");
		String role=scanner.next();
		flag=utility.isValidRole(role);
		if(flag==true)
			user.setRole(role);
		else System.out.println("Invalid role. Enter again!!");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter UserName:");
		String user_name=scanner.next();
		flag=utility.isValidUserName(user_name);
		if(flag==true)
			user.setUser_name(user_name);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter Mobile No.:");
		String mobile_no=scanner.next();
		flag=utility.isValidMobileNo(mobile_no);
		if(flag==true)
			user.setMobile_no(mobile_no);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		
		
		do {
		System.out.println("Enter Phone NO.:");
		String phone=scanner.next();
		flag=utility.isValidPhoneNo(phone);
		if(flag==true)
			user.setPhone(phone);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		System.out.println("Enter Address");
		user.setAddress(scanner.next());
		//flag=false;
		
		do {
		System.out.println("Enter Email:");
		String email=scanner.next();
		flag=utility.isValidEmail(email);
		if(flag==true)
			user.setEmail(email);
		else
			System.out.println("Invalid");
		}while(flag==false);
		
		
		do {
		System.out.println("Enter Password");
		String password=scanner.next();
		
		
		System.out.println("Re-enter Password");
		String password1=scanner.next();
		
		if(password.equals(password1)) {
			user.setPassword(password);
			flag=true;}
		else {System.out.println("Passwords did not Match");
				flag=false;	}
		}while(flag==false);
		
		return user;
		
		
		
		
		
		
		
	}
	public int promptNo_of_rooms() {
	System.out.println("enter no.of rooms you wnat to book");
	
		return scanner.nextInt();
	}
}
