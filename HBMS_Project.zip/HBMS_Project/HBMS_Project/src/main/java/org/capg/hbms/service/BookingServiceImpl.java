`package org.capg.hbms.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

import org.capg.hbms.dao.BookingDaoImpl;
import org.capg.hbms.dao.IBookingDao;
import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.view.UserInteraction;

public class BookingServiceImpl implements IBookingService {
IBookingDao bookingdao=new BookingDaoImpl();
IRoomService roomService=new RoomServiceImpl();

	@Override
	public void addbooking(BookingDetails bookingdetails) {
		bookingdao.addbooking(bookingdetails);
		
	}
public BookingDetails findAmount(BookingDetails bookingDetails)
{
	
	
	int roomid=bookingDetails.getRoom_id();
	Double roomRate=roomService.roomRate(roomid);
     long days=ChronoUnit.DAYS.between(bookingDetails.getBooked_to(),bookingDetails.getBooked_from());
	if( days==0)
	{
	  days=1;
	}
	Double totalAmount=roomRate*days;
	
		
	bookingDetails.setAmount(totalAmount);
	return bookingDetails;
}

public Set<BookingDetails> getBookingDetails(int customerId){
	
	return bookingdao.getBookingDetails(customerId);
}
@Override
public List<BookingDetails> getBookings(LocalDate of) {
	
	return bookingdao.getBookings(of);
}

}
